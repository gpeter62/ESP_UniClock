                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3417955
IV18 WIFI VFD nixie clock (PCB less) by aeropic is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

I wanted to design the simplest to build (not really) nixie clock:
- a clock nearly everybody could build with only soldering skills ...
- a clock that would autonomously synchronize to the NTP time
- a clock that would be nice or at least with a cool look ;-)
- a clock that could be built without any specific PCB
- a clock whose price would be in the range of 20€

The timezone is managed as well as the automatic summer time...

As the quartz of the ESP8266 has some thermal drift, a systematic  synchro to NTP time is performed at 3:00 in the morning


# How I Designed This

## BOM

Here we are, you need to buy:
- an old russian IV18 Vacuum Fluorescent Display tube. I bought mine here (sold by 2 for 17€):
https://www.ebay.fr/itm/2x-IV-18-Hour-indicators-USSR/163508896336?hash=item2611e3c250:g:gacAAOSwyCZbhh7y:rk:34:pf:0
-  an ESP8266 ESP-12  WeMos D1 Mini WIFI CH340G (found on ebay for 2.8€)
- a MAXIM SOP-28 MAX6921 VFD driver (found here for 4.2 €) 
https://www.ebay.fr/itm/1PCS-VFD-Tube-Drivers-IC-MAXIM-SOP-28-MAX6921AWI-MAX6921AWI-MAX6921AWI-T/362255976293?ssPageName=STRK%3AMEBIDX%3AIT&_trksid=p2057872.m2749.l2649
- a small PCB SOP28 to DIP28 adapter to solder your SMD driver. Found here by 5 for 1€:
https://www.ebay.fr/itm/5PCS-SOP28-SSOP28-TSSOP28-to-DIP28-Adapter-Converter-PCB-Board-0-65-1-27mm/173323623387?hash=item285ae49bdb:g:X60AAOSwYeNa~k5H:rk:1:pf:0
- a step up boost converter to generate 30V from 5V. found on ebay for 1.9€
LM2587 DC-DC Boost Converter 3-30V Step up to 4-35V Power Supply Module MAX 5A
- any phone charger with a micro USB plug
- a small diode (any diode will dot the job) I unsoldered mine from a dead electronic device ...


## getting started with the arduino ESP8266

unzip the archive and place the two files into a single directory.

to upload the firmware into the Wemos ESP8266 you'll need to be familiar with arduino IDE environment. There are plenty good explanations on the internet. jsut seach for "arduino ESP8266).

Plug the wemos into an USB port and you should see the device mounted as a serial port.
Assuming, your environment and board are both ready to operate you should ne able to open the source code file and compile it.
Uploading the firmware can be done very easily from the USB serial port.

When uploaded you can start playing with the ESP8266 and enjoy the Wifi  configuration which is semi-automatic...
The first time the ESP8266 is powered it will not find any WiFI configuration (SSID and password) and will then ask for one. It generates a new wifi access point to which you will connect from a smartphone. Once connected, 
- open the browser and type in the address : "192.168.4.1" to access the configuration web page
- then select the "CONFIGURE WIFI" tab,
- then click on your wifi SSID and add the password 
- then save

That's all, reset the ESP8266 and it should now connect to your WiFi SSID from which it will find the time

## setting the tube brigthness

the brightness of the tube can be set up from the internet as this is an IOT clock ;-)
If your PC is correctly configured the name of the clock from the local network is : "iv18_clock.local"

Just type in any browser from the local network this line :
http://iv18_clock.local/?B=80
and the tune's brightness will be set to 80%
Change 80 to your preferred value such as 
http://iv18_clock.local/?B=50
et voilà !

## in case of flicker

Should you see some flicker of the display especially at low brightness this means that the ESP is not powerfull enough to manage both the wifi tasks and the display refresh at high rate.
There is an option to kill  the wifi... Just type in the web browser this line:
http://iv18_clock.local/?B=9999

==> no more wifi up to the next reset !

## the hardware ...

first solder the MAX6921 on the small PCB.
Then cut the 3 not connected pins of the IV18 (you see there is no inside wire in the tube - blue arrows here after).
Insert the tubes wires into the PCB holes following the schematic and gently bend them to align the tube to the top of the PCB (see pictures)




![Alt text](https://cdn.thingiverse.com/assets/84/5f/7a/ed/e1/cut678.png)
cut pins 6,7,8

![Alt text](https://cdn.thingiverse.com/assets/4f/5c/76/21/ea/20190210_111618.jpg)

![Alt text](https://cdn.thingiverse.com/assets/e1/e0/2a/22/7e/20190210_111554.jpg)

![Alt text](https://cdn.thingiverse.com/assets/d1/35/0d/80/39/max6921_-_IV18.png)

do not forget to solder the diode on pin 13 of the tube (set it in the right orientation). The Before soldering the tube, test that the thickness of the tube+PCB  is OK with the thickness of the printed support. If not, just fix the shape bending the wires...

pin 13 is routed through the hole of the PCB. Same thing for pin 1 which is then soldered to the ground pin .

Solder 7 long thin wires to the following pins:
- VBB
- Vcc
- DIN
- LOAD
- CLK
- GND
- BLANK


![Alt text](https://cdn.thingiverse.com/assets/e4/46/1e/2a/76/20190210_115636.jpg)

solder 6 wires to the wemos ESP8266:
- +5V
- G (as GND)
- D5
- D6
- D7 
- D8

connect the power lines to the bulk converter
- +5V to IN+
- GND to IN-

Power the ESP8266 with the USB connector just to check the voltage of the bulk converter. Rotate the potentiometer in order to reach the maximum value at the output (something close to 45V, but if you only get 30V, it will work as well).

remove the power and finish the wirings:
- VBB  to Vout+ ot the bulk converter
- Vcc to + 5V of the ESP (or IN+ of the converter) 
- DIN to D5
- LOAD to D6
- CLK to D7
- GND to GND
- BLANK to D8

Checj everything again and power to test ...

## final setting

Once everything is running fine, you can install the hardware into the printed parts.
- insert a M3 nut into the support hole, screw a screw to press fit the nut in position
- Slide the support from the tip of the tube
- insert the wires into the support's slot
- cut the right thin wall of the basement so that the bulk converter will find its room
- insert the wires into the basement's slot
- screw the support to the basement
- glue the cover to the support using CA glue
- insert the ESP into its slot, plug a USB wire to facilitate its centering
- hot glue the ESP in position
- place the bulk converter
- hot glue it in position.
- route the wires to get a  nice looking wiring

![Alt text](https://cdn.thingiverse.com/assets/ff/e4/b6/bf/fb/20190210_161849.jpg)

## adding a motion dectection radar

The IV18 lifespan is given to be not more than 30000 hours. It could then be a good idea to switch off the tube and part of teh electronics when nobody is in the room to watch the clock.
Fortunately it exists a little cheap radar than can do the job for one Euro .
Just search for RCWL-0516 on ebay...
Great source of information here : https://github.com/jdesbonnet/RCWL-0516


![Alt text](https://cdn.thingiverse.com/assets/ec/aa/33/d7/6e/RCWL-0516-board.jpg)

wiring the radar is quite straitforward:
- GND is connected to ESP8266 GNG
- VIN is connected to ESP8266 +5V
- OUT is connected to GPIO16 (pin D0 of the wemos board)

It is safe to do this as the radar includes its own 3.3V regulator and its output is between 0V and 3.3V.

With this the ESP is able to know the radar has detected somebody in the room. A timer is set to 5 minutes to keep the clock ON up to five minutes after the radar detects no motion in the room, then the tube is turned OFF.

## turning OFF the electronics : a mosfet !

remember we do not have a PCB, we will then wire solder a small mosfet to amplify the output of the ESP. (The ESP IO can drive no more than 12mA).
the mosfet I use is a N channel 2N7002K but you can use any N channel one


![Alt text](https://cdn.thingiverse.com/assets/41/6b/0a/43/41/mosfet.png)

- solder the mosfet by its drain (pin 3) to the IN- pad of the bulk converter
- solder the mosfet's  source (S pin 2) to the ESP GND
- solder the Gate (pin 1) to the ESP GPIO2 (pin D4 of the wemos board)

And that is, your radar is now fully operational!

install the radar board at the right : leave the surface of the radar fully clear of any wire as those things are quite sensitive !

![Alt text](https://cdn.thingiverse.com/assets/c3/bf/d0/fb/eb/mosfet_pad.png)

![Alt text](https://cdn.thingiverse.com/assets/27/fa/76/2b/e1/20190217_164736.jpg)

![Alt text](https://cdn.thingiverse.com/assets/e7/26/0c/82/87/wemos_pinout.png)

## TODO ...

in a future version I plan to add the following features :

- add a small button to manage the tube brightness and switch it off during night.
- add some preferences in the software
- store the wifi status in the preferences so that once switched off it just starts after reset to synchronize to FTP then switches off again
- add the timezone and DST in the preferences and program then from the web server.
     
Please comment and like if you get nice ideas or simply want to encourage me! And if you really really like it, you may consider a tip ;-)