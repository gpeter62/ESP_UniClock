# WirelessOregonV2 library
This version is compatible with Arduino family microcontrollers and esp8266.
